package phase3;


import java.io.IOException;
import java.util.Scanner;

public class TeacherUser extends User {

    TeacherAccount Teacher;
    Scanner in = new Scanner(System.in);
    MCQGame mc;
    TF_Game tf;
    Registration reg = new Registration();

    public TeacherUser() {
    }

    public void CreateGame() throws IOException {
        
        System.out.println("Enter Description of game: ");
        String d = in.nextLine();
        System.out.println("Enter Category: ");
        String c = in.next();
        System.out.println("Enter type of game: ");
        String t = in.next();
        System.out.println("Enter the name of game: ");
        String nam = in.next();
        reg.gameName.add(nam + t);
        db.SaveGames(nam, t , c);
        if (t.equals("MCQ")) {
            mc = new MCQGame(d, c);
            mc.SetQuestions(nam);
        }

        if (t.equals("T-F")) {
            tf = new TF_Game(d, c);
            tf.SetQuestions(nam);
        }
    }
    public void DeleteGame(){
        System.out.println("write the name of game: ");
        String name = in.next();
        if(reg.gameName.contains(name)){
            reg.gameName.remove(name);
            System.out.println("Successful delete");
        }
        System.out.println("the game is not found");
    }
    public void EditGame() throws IOException{
        DeleteGame();
        CreateGame();
    }
}
