package phase3;


import java.util.ArrayList;

public class TeacherAccount extends Account {

    String Degree;
   

    public TeacherAccount(String Name, int Age, String Gender, String Mail, String Password) {
        super(Name, Age, Gender, Mail, Password);
    }
   
    public String getDegree() {
        return Degree;
    }

    public void setDegree(String Degree) {
        this.Degree = Degree;
    }

}
