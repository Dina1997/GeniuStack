package phase3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class DataBase {
    public static HashMap<String , Integer> scores = new HashMap<String , Integer>();
    public static ArrayList<StudentAccount> students = new ArrayList<StudentAccount>();
    public static ArrayList<TeacherAccount> teachers = new ArrayList<TeacherAccount>();
    FileWriter fw;
    BufferedWriter bw;

    public DataBase() {
    }

    public void SaveAccounts() throws IOException {
        fw = new FileWriter("Student Accounts.txt", true);
        bw = new BufferedWriter(fw);
        //System.out.println(students);
        for (int i = 0; i < students.size(); i++) {
            bw.write(students.get(i).Name);
            bw.newLine();
            bw.write(students.get(i).Password);
            bw.newLine();
            bw.write(students.get(i).Mail);
            bw.newLine();
            bw.write("------------------------");
            bw.newLine();
        }
        bw.close();

        fw = new FileWriter("Teacher Accounts.txt", true);
        bw = new BufferedWriter(fw);
        for (int i = 0; i < teachers.size(); i++) {
            bw.write(teachers.get(i).Name);
            bw.newLine();
            bw.write(teachers.get(i).Password);
            bw.newLine();
            bw.write(teachers.get(i).Mail);
            bw.newLine();
            bw.write("------------------------");
            bw.newLine();
        }
        bw.close();
    }

    public void SaveGames(String gameName, String type, String cat) throws IOException {
        if (cat.equals("Chemical")) {
            fw = new FileWriter("Chemical games.txt", true);
            bw = new BufferedWriter(fw);
            bw.write(gameName + type);
            bw.newLine();
            bw.close();
        }
        if (cat.equals("English")) {
            fw = new FileWriter("English games.txt", true);
            bw = new BufferedWriter(fw);
            bw.write(gameName + type);
            bw.newLine();
            bw.close();
        }
    }
    public void SaveScore(int score , String name) throws IOException{
        fw = new FileWriter("Scores.txt", true);
        bw = new BufferedWriter(fw);
        bw.write(name+ " --> ");
        bw.write(String.valueOf(score));
        bw.newLine();
        bw.close();
        fw.close();
    }
}
