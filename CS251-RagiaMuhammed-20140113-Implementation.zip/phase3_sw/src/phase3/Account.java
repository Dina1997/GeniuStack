package phase3;


public  class Account {
	String Name;
	int Age;
	String Gender;
	String Mail;
	String Password;
        int level;

	public Account(String Name, int Age, String Gender,  String Mail, String Password) {
		this.Name = Name;
		this.Age = Age;
		this.Gender = Gender;
		this.Mail = Mail;
		this.Password = Password;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public void setAge(int Age) {
		this.Age = Age;
	}

	public void setGender(String Gender) {
		this.Gender = Gender;
	}

	

	public void setMail(String Mail) {
		this.Mail = Mail;
	}

	public void setPassword(String Password) {
		this.Password = Password;
	}

	public String getName() {
		return Name;
	}

	public int getAge() {
		return Age;
	}

	public String getGender() {
		return Gender;
	}



	public String getMail() {
		return Mail;
	}

	public String getPassword() {
		return Password;
	}

}
