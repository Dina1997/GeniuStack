package phase3;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class User {

    ArrayList<String> questions = new ArrayList<>();
    ArrayList<String> truechoice = new ArrayList<>();
    String choice;
    Scanner in = new Scanner(System.in);
    public int score = 0;
    DataBase db = new DataBase();
    Comment ob = new Comment();

    public User() {

    }

    public void ShowCategories() throws IOException {
        String OutputCategories;
        OutputCategories = new String(Files.readAllBytes(Paths.get("Categories.txt")));
        System.out.println(OutputCategories);
    }

    public void ShowGames(String cat) throws IOException {
        String games;
        if (cat.equals("Chemical")) {
            games = new String(Files.readAllBytes(Paths.get("Chemical games.txt")));
            System.out.println(games);
        } else if (cat.equals("English")) {
            games = new String(Files.readAllBytes(Paths.get("English games.txt")));
            System.out.println(games);
        }
    }

    public int PlayGame(String gamename, String Category) {
        String GameType = gamename.substring(gamename.length() - 3, gamename.length());
        if (GameType.equals("MCQ")) {
            MCQGame mcq = new MCQGame(Category);
            questions.addAll(mcq.GetQuestions());
            truechoice.addAll(mcq.GetAnswer());
            //  System.out.println(questions);
            for (int i = 0; i < questions.size(); i++) {
                System.out.println(questions.get(i));
                choice = in.next();
                if (choice.equals(truechoice.get(i))) {
                    score++;
                }
            }
            System.out.println("The score is " + score + " / 5");
            System.out.println("Do You want to Write Comment ?");
            String Choice;
            Choice = in.next();
            if (Choice.equals("Y")) {
                ob.AddComment();
            }
            System.out.println("\"Do You want to Write Reply ?");
            Choice = in.next();
            if (Choice.equals("Y")) {
                ob.AddReply();
            }else{System.out.println("thank you");}
            GameType = "";
            questions.clear();
            truechoice.clear();
            return score;
        }

        if (GameType.equals("T-F")) {
            TF_Game tf = new TF_Game(Category);
            questions.addAll(tf.GetQuestions());
            truechoice.addAll(tf.GetAnswer());
            for (int i = 0; i < questions.size(); i++) {
                System.out.println(questions.get(i));
                choice = in.next();
                if (choice.equals(truechoice.get(i))) {
                    score++;
                }
            }
            System.out.println("The score is " + score + " / 5");
            
            System.out.println("Do You want to Write Comment ?");
            String Choice;
            Choice = in.next();
            if (Choice.equals("Y")) {
                ob.AddComment();
            }
            System.out.println("\"Do You want to Write Reply ?");
            Choice = in.next();
            if (Choice.equals("Y")) {
                ob.AddReply();
            }else { System.out.println("Thank you");}
            GameType = "";
            questions.clear();
            truechoice.clear();
            return score;
        }

        return 0;
    }
}
