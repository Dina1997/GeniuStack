package phase3;



public class StudentAccount extends Account {
    int level;

    public StudentAccount(String Name, int Age, String Gender, String Mail, String Password) {
        super(Name, Age, Gender, Mail, Password);
        level++;
    }

    public int getLevel() {
        return level;
    }
    

}
