package phase3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Game {
	public int FinalRate;
	String Description;
	String categories;
	static double rate1 = 0 , num1 =0;
	static double rate2 = 0 , num2 =0;
	static double rate3 = 0 , num3=0;
	static double rate4 = 0 , num4=0;
	Scanner in = new Scanner(System.in);
        FileWriter fw;
    BufferedWriter bw;
	
	public Game() {

	}
	
	public Game(String categories) {
		super();
		this.categories = categories;
	}

	public Game(String description, String categories) {
		Description = description;
		this.categories = categories;
	}

	public void CalculateRate(String gamename) {
		String choice; int rate;
		System.out.println("Rate ?");
		choice = in.next();
		if (choice.equals("Y")) {
			System.out.print("Rate from 1 to 5: ");
			rate = in.nextInt();
			if (gamename.equals("ChemicalT-F")) {
				rate1 += rate;
				num1++;
				rate1 /= num1;
                                System.out.println("rate this game is "+ rate1);
			}
			if (gamename.equals("ChemicalMCQ")) {
				rate2 += rate;
				num2++;
				rate2 /= num2;
                                System.out.println("rate this game is "+ rate2);
			}
			if (gamename.equals("SyllablesT-F")) {
				rate3 += rate;
				num3++;
				rate3 /= num3;
				System.out.println("rate this game is "+ rate3);
			}
			if (gamename.equals("syllableMCQ")) {
				rate4 += rate;
				num4++;
				rate4 /= num4;
                                System.out.println("rate this game is "+ rate4);
			}
		}
	}
	public abstract void SetQuestions(String name) throws IOException;
	public abstract ArrayList<String> GetQuestions();	
	public abstract ArrayList<String> GetAnswer();
	
}


