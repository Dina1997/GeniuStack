package phase3;


public class StudentUser extends User {

    StudentAccount student;

    public StudentUser() {
    }

    public int RateGame(String Category, String gamename) {
        MCQGame g = new MCQGame();
        int score = PlayGame(gamename, Category);
        g.CalculateRate(gamename);
        return score;
    }
}
