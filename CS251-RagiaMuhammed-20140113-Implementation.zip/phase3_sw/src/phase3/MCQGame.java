package phase3;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class MCQGame extends Game {

    char choice;
    Scanner in = new Scanner(System.in);
    Scanner ReadMCQQuestion;
    ArrayList<String> questions = new ArrayList<>();
    ArrayList<String> answers = new ArrayList<String>();
    private static FileWriter write;

    public MCQGame(String description, String categories) {
        super(description, categories);
    }

    public MCQGame(String categories) {
        super(categories);
    }

    public MCQGame() {
    }

    public char getChoice() {
        return choice;
    }

    public void setChoice(char choice) {
        this.choice = choice;
    }

    public void Read(Scanner Read) {
        while (ReadMCQQuestion.hasNext()) {
            String Question = "";
            int i = 0;
            while (i < 5) {
                Question += ReadMCQQuestion.nextLine();
                Question += "\n";
                i++;
            }
            questions.add(Question);
        }
        ReadMCQQuestion.close();
    }

    @Override
    public ArrayList<String> GetQuestions() {

        if (categories.equals("Chemical")) {
            try {
                ReadMCQQuestion = new Scanner(new File("Chemical FamiliesMCQ.txt"));
                Read(ReadMCQQuestion);
                return questions;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        if (categories.equals("English")) {
            try {
                ReadMCQQuestion = new Scanner(new File("syllableMCQ.txt"));
                Read(ReadMCQQuestion);
                return questions;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public ArrayList<String> GetAnswer() {

        if (categories.equals("Chemical")) {
            String[] str = new String[]{"b", "b", "d", "d", "d"};
            for (int i = 0; i < str.length; i++) {
                answers.add(str[i]);
            }
            return answers;
        }
        if (categories.equals("English")) {
            String[] str = new String[]{"a", "c", "d", "b", "a"};
            for (int i = 0; i < str.length; i++) {
                answers.add(str[i]);
            }
            // System.out.println(answers);
            return answers;
        }
        return null;
    }

    @Override
    public void SetQuestions(String name) throws IOException {
        fw = new FileWriter(name+"MCQ.txt", true);
        bw = new BufferedWriter(fw);
        System.out.println("Enter the 5 questions: ");
        String q = "";
        String a = "";
        for (int i = 0; i < 5; i++) {
            q = in.next();
            bw.write(q);
            bw.newLine();
            for (int x = 0; x < 4; x++) {
                a = in.next();
                bw.write(a);
                bw.newLine();
            }
        }
        bw.close();
    }

}