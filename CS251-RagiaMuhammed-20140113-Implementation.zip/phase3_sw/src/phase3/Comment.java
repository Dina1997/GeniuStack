package phase3;


import java.util.Scanner;
import java.util.Vector;

public class Comment {

    String Comment;
    String GameName;
    Vector<String> Replies = new Vector<String>();
    Vector<Comment> Objects = new Vector<Comment>();
    Scanner in = new Scanner(System.in);

    public void AddComment() {
        String GameName;
        String UserComment;
        System.out.println("Please Enter GameName");
        GameName = in.next();
        System.out.println("Please Enter your Comment");
        UserComment = in.next();
        Comment Ob = new Comment();
        Ob.GameName = GameName;
        Ob.Comment = UserComment;
        Objects.add(Ob);

    }

    public void AddReply() {
        String Reply = "";
        String SelectedGame = "";
        String SelectedComment;
        System.out.println("Please Enter SelectedGame");
        SelectedComment = in.next();
        System.out.println("Please Enter SelectedComment");
        SelectedComment = in.next();
        System.out.println("Please Enter your Reply");
        GameName = in.next();
        Comment Obj = new Comment();
        for (int i = 0; i < Objects.size(); i++) {
            if (Objects.get(i).Comment == SelectedComment && Objects.get(i).GameName == SelectedGame) {
                Obj.Replies.add(Reply);
                Objects.add(Obj);

            } else {
                System.out.println("Wrong Entrey");
            }
        }
    }
}
