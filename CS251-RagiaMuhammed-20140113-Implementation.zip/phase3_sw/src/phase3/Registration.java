package phase3;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Registration {

    Scanner Read;
    static DataBase y = new DataBase();
    public ArrayList<String> gameName = new ArrayList<String>();

    public boolean signup(String Name, int Age, String Gender, String Mail, String Password, String state) {
        if ("teacher".equals(state)) {
            TeacherAccount x = new TeacherAccount(Name, Age, Gender, Mail, Password);
            y.teachers.add(x);
        } else if ("student".equals(state)) {
            StudentAccount x = new StudentAccount(Name, Age, Gender, Mail, Password);
            y.students.add(x);
        }

        return true;
    }

    public boolean signin(String username, String password, String state) throws FileNotFoundException, IOException {
        if ("student".equals(state)) {
            String str = new String(Files.readAllBytes(Paths.get("Student Accounts.txt")));
            if(str.contains(username)){
                if(str.contains(password))
                    return true;
            }
            return false;

        } else if ("teacher".equals(state)) {
            String str = new String(Files.readAllBytes(Paths.get("Teacher Accounts.txt")));
            if(str.contains(username)){
                if(str.contains(password))
                    return true;
            }
            return false;

        }

        return false;
    }
//    public static boolean isValidEmailAddress(String email) {
//   boolean result = true;
//   try {
//      InternetAddress emailAddr = new InternetAddress(email);
//      emailAddr.validate();
//   } catch (AddressException ex) {
//      result = false;
//   }
//   return result;
//}
}
