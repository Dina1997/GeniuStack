package phase3;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class play {

    public static void main(String[] args) throws IOException {
        Registration reg = new Registration();
        User use = new User();
        String user;
        DataBase db = new DataBase();
        Scanner in = new Scanner(System.in);
        int score = 0;
        String New = ""; 
        while(true){
            System.out.println("1- (Sign in) 2- (Sign up) ");
            int num = in.nextInt();
            if (num == 1) {
                System.out.print("user name: ");
                user = in.next();
                System.out.print("Password: ");
                String pass = in.next();
                System.out.println("Student or Teacher ? ");
                String state = in.next();
                db.scores.put(user, score);
                boolean valid = reg.signin(user, pass, state);
                if (valid) {
                    if (state.equals("student")) {
                        use.ShowCategories();
                        System.out.println("Choose category: ");
                        String cat = in.next();
                        use.ShowGames(cat);
                        System.out.println("Choose game to play: ");
                        String gamename = in.next();
                        StudentUser stu = new StudentUser();
                        score = stu.RateGame(cat, gamename);
                        int s1 = DataBase.scores.get(user);
                        db.SaveScore(score+s1 , user);
                    } else if (state.equals("teacher")) {
                        TeacherUser te = new TeacherUser();
                        System.out.println("1- (play game) 2- (Create game) 3- (Edit) 4- (Delete)");
                        int choice = in.nextInt();
                        if (choice == 1) {
                            use.ShowCategories();
                            System.out.println("Choose category: ");
                            String cat = in.next();
                            use.ShowGames(cat);
                            System.out.println("Choose game to play: ");
                            String gamename = in.next();
                            use.PlayGame(gamename, cat);
                            int s1 = DataBase.scores.get(user);
                            db.SaveScore(score+s1 , user);
                        } else if (choice == 2) {
                            te.CreateGame();
                        } else if (choice == 3) {
                            te.EditGame();
                        } else if (choice == 4) {
                            te.DeleteGame();
                        }
                    }
                } else {
                    System.out.println("Not valid");
                }
            } else if (num == 2) {
                System.out.print("your name: ");
                String Name = in.next();
                System.out.print("your Age: ");
                int age = in.nextInt();
                System.out.print("Gender: ");
                String Gender = in.next();
                System.out.println("you are Student or Teacher ?");
                String state = in.next();
                System.out.print("your Mail: ");
                String Mail = in.next();
                System.out.print("Enter password: ");
                String Password = in.next();
                reg.signup(Name, age, Gender, Mail, Password, state);
                db.SaveAccounts();
            }
            if(true){
                System.out.println("New user ?");
                New = in.next();
                if(!New.equals("Y"))
                    break;
            }
        }
        // StudentUser stu = new StudentUser();
        //stu.RateGame("Chemical", "ChemicalT-F");
    }
}
